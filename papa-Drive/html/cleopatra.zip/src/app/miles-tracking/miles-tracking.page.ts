import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miles-tracking',
  templateUrl: './miles-tracking.page.html',
  styleUrls: ['./miles-tracking.page.scss'],
})
export class MilesTrackingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
