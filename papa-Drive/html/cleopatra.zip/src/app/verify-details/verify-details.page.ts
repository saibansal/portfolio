import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-details',
  templateUrl: './verify-details.page.html',
  styleUrls: ['./verify-details.page.scss'],
})

export class VerifyDetailsPage implements OnInit {
  constructor() {}
  ngOnInit() {}
}
