$(document).ready(function () {
  (function () {
    'use strict';
    window.addEventListener('load', function () {
      var forms = document.getElementsByClassName('needs-validation');
      var validation = Array.prototype.filter.call(forms, function (form) {
        form.addEventListener('submit', function (event) {
          if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }, false);
      });
    }, false);
  })();

  var o = $("#header");
  $(document).scroll(function () {
    $(window).scrollTop() ? o.addClass("sticky") : o.removeClass("sticky")
  }), $(window).scrollTop() && o.addClass("sticky")

  $('.carousel').carousel({
    interval: 1000 * 6,
    Touch: true
  }); 

  // $(".carousel").swipe({
  //   swipe: function (event, direction, distance, duration, fingerCount, fingerData) {
  //     if (direction == 'left') $(this).carousel('next');
  //     if (direction == 'right') $(this).carousel('prev');
  //   },
  //   allowPageScroll: "vertical"
  // }); 
  
  $(".menuClose ").click(function () {
    $(".headerMenu").removeClass('showMenu');
  });

  $(".nv__btn").click(function () {
    $(".headerMenu").addClass('showMenu');
  }); 
});

$('.customer-logos').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: false,
  autoplaySpeed: 50000,
  arrows: true,
  dots: false, 
  pauseOnHover: false,
  responsive: [{
      breakpoint: 768,
      settings: {
          slidesToShow: 3
      }
  }, {
      breakpoint: 520,
      settings: {
          slidesToShow: 3
      }
  }]
});