$(document).ready(function(){
  $('.the-nav').cbFlyout();
});