// JavaScript Document
// for inpout type placeholder
 $(function() {
  $('input, textarea').placeholder();
 });
function login(){
		$('#dropdown').toggle();
		}
