// JavaScript Document
$(function () {
    $('.bg').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	    $('.bg1').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg1')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg2').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg2')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg3').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg3')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg4').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg4')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg5').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg5')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg6').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg6')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	  $('.bg7').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg7')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
	$('.bg8').on('mouseover', 'a', function () {
        var background = "url('" + $(this).attr('data-background') + "')";

        $('.bg8')
            .stop()
            .css('opacity', 0)
            .css('background-image', background)
            .animate({opacity: 1});
    });
});